package wildsas.blablawild;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
/**
 * Created by apprenti on 06/03/17.
 */


// Ici on lie le XML qui sert de modele à un item de la liste à l'adapter et à l'objet TripResultModel //

public class TripResultAdapter extends BaseAdapter{

    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy-hh:mm");

    private Context mContext;
    public TripResultAdapter(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        // inflate the layout for each list row
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).
                    inflate(R.layout.trip_item, parent, true); //ON DONNE LE NOM DU XML MODELE D'ITEM//
        }

        // get current item to be displayed
        TripResultModel currentItem = (TripResultModel) getItem(position);

        // get the TextView for item name and item description

        TextView textViewmFirstName = (TextView) convertView.findViewById(R.id.textViewFirstName);
        TextView textViewmDepartureTime = (TextView) convertView.findViewById(R.id.textViewDepartureTime);
        TextView textViewPrice = (TextView) convertView.findViewById(R.id.textViewPrice);


        textViewmFirstName.setText(currentItem.getmFirstName());
        textViewmDepartureTime.setText(sdf.format(currentItem.getmDepartureTime()));
        textViewPrice.setText(currentItem.getmPrice());
        // [...]

        // returns the view for the current row
        return convertView;
    }
}
